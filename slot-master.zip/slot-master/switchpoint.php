<?php 
				switch($num1)
                {
                    case "0":
					$pointWin = 5;
                    break;

                    case "1":
                    $pointWin = 10;
                    break;
					                    
                    case "2":
                    $pointWin = 20;
                    break;
                    
                    case "3":
                    $pointWin = 50;
                    break;
                    
                    case "4":
                    $pointWin = 100;
                    break;
                }
?>