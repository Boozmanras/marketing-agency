<?php
$sausage = "<img src='gfx/sausage.png' />";
$dead = "<img src='gfx/dead.png' />";
$eye = "<img src='gfx/eye.png' />";
$splat = "<img src='gfx/splat.png' />";
$seven = "<img src='gfx/7.png' />";
switch($num1)
                {
                  case "0":
                  print $sausage;
                  break;

                  case "1":
                  print $dead;
                  break;

                  case "2":
                  print $eye;
                  break;

                  case "3":
                  print $splat;
                  break;

                  case "4":
                  print $seven;
                  break;
                }
				switch($num2)
                {
                  case "0":
                  print $sausage;
                  break;

                  case "1":
                  print $dead;
                  break;

                  case "2":
                  print $eye;
                  break;

                  case "3":
                  print $splat;
                  break;

                  case "4":
                  print $seven;
                  break;
                }
				switch($num3)
                {
                  case "0":
                  print $sausage;
                  break;

                  case "1":
                  print $dead;
                  break;

                  case "2":
                  print $eye;
                  break;

                  case "3":
                  print $splat;
                  break;

                  case "4":
                  print $seven;
                  break;
                }
?>
